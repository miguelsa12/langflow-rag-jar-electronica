import uuid
from typing import List, Union, Generator, Iterator

import requests
from pydantic import BaseModel, Field


class Pipeline:
    class Valves(BaseModel):
        # OPCION FACIL:
        # Si Langflow y Open WebUI estan en namespaces distintos, solo cambie LANGFLOW_NAMESPACE.
        LANGFLOW_NAMESPACE: str = Field(
            default="langflow",
            description="Namespace donde esta instalado Langflow. Ejemplo: langflow, usuario-proyecto, mlops-langflow."
        )
        LANGFLOW_SERVICE_NAME: str = Field(
            default="langflow-service-backend",
            description="Nombre del Service backend de Langflow. En este chart corregido es langflow-service-backend."
        )
        LANGFLOW_SERVICE_PORT: int = Field(
            default=7860,
            description="Puerto interno del backend de Langflow."
        )

        # OPCION AVANZADA:
        # Si usted pone LANGFLOW_BASE_URL, se usa esta URL completa y se ignoran namespace/service/port.
        LANGFLOW_BASE_URL: str = Field(
            default="",
            description="URL completa opcional. Ejemplo: http://langflow-service-backend.mi-namespace.svc.cluster.local:7860"
        )
        LANGFLOW_FLOW_ID: str = Field(
            default="YOUR_FLOW_ID",
            description="UUID del Flow de Langflow que quiere ejecutar."
        )
        LANGFLOW_API_TOKEN: str = Field(
            default="langflow-pcai-internal-key",
            description="API key interna de Langflow configurada en el chart corregido."
        )
        VERIFY_SSL: bool = Field(
            default=False,
            description="No aplica para HTTP interno. Dejelo en False en PCAI/Ezmeral si usa servicio interno."
        )

    def __init__(self):
        self.valves = self.Valves()
        self.name = "LangFlow RAG"

    async def on_startup(self):
        print(f"on_startup: {self.name}")

    async def on_shutdown(self):
        print(f"on_shutdown: {self.name}")

    def _base_url(self) -> str:
        if self.valves.LANGFLOW_BASE_URL and self.valves.LANGFLOW_BASE_URL.strip():
            return self.valves.LANGFLOW_BASE_URL.strip().rstrip("/")

        namespace = self.valves.LANGFLOW_NAMESPACE.strip()
        service = self.valves.LANGFLOW_SERVICE_NAME.strip()
        port = self.valves.LANGFLOW_SERVICE_PORT
        return f"http://{service}.{namespace}.svc.cluster.local:{port}"

    def pipe(
        self, user_message: str, model_id: str, messages: List[dict], body: dict
    ) -> Union[str, Generator, Iterator]:
        base_url = self._base_url()
        flow_id = self.valves.LANGFLOW_FLOW_ID.strip()

        if not flow_id or flow_id == "YOUR_FLOW_ID":
            return "Config error: falta poner LANGFLOW_FLOW_ID con el ID real del flow de Langflow."

        url = f"{base_url}/api/v1/run/{flow_id}"
        headers = {
            "x-api-key": self.valves.LANGFLOW_API_TOKEN,
            "Content-Type": "application/json",
        }

        session_id = body.get("chat_id", str(uuid.uuid4()))
        payload = {
            "output_type": "chat",
            "input_type": "chat",
            "input_value": user_message,
            "session_id": session_id,
        }

        try:
            response = requests.post(
                url,
                json=payload,
                headers=headers,
                verify=self.valves.VERIFY_SSL,
                timeout=120,
            )

            if response.status_code == 403:
                return (
                    "Langflow respondio 403 Forbidden. Revise principalmente: "
                    "1) que LANGFLOW_API_TOKEN sea igual a LANGFLOW_API_KEY del chart; "
                    "2) que LANGFLOW_BASE_URL o LANGFLOW_NAMESPACE apunten al backend interno; "
                    "3) que este usando x-api-key, no Authorization Bearer. "
                    f"URL usada: {url}. Respuesta: {response.text[:1000]}"
                )

            response.raise_for_status()
            response_json = response.json()

            try:
                return response_json["outputs"][0]["outputs"][0]["results"]["message"]["data"]["text"]
            except (KeyError, IndexError, TypeError):
                return f"Langflow respondio, pero el formato no fue el esperado. Respuesta cruda: {response.text}"

        except requests.exceptions.RequestException as e:
            return f"Error making API request to LangFlow: {e}. URL usada: {url}"
        except Exception as e:
            return f"An unexpected error occurred: {e}"
