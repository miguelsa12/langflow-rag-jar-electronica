#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/generated-tgz"
mkdir -p "$OUT_DIR"

helm lint "$ROOT_DIR/helm-source/langflow-ide"
helm package "$ROOT_DIR/helm-source/langflow-ide" --destination "$OUT_DIR"

helm lint "$ROOT_DIR/helm-source/open-webui"
helm package "$ROOT_DIR/helm-source/open-webui" --destination "$OUT_DIR"

echo "Generated packages:"
ls -lh "$OUT_DIR"
