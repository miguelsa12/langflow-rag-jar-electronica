# Paquete con nombres originales: `langflow-ide` y `open-webui`

Este paquete mantiene los nombres originales de los frameworks/charts, pero cambia la versión del chart para intentar evitar conflicto al importar en HPE PCAI.

## Archivos incluidos

```text
helm-source/
  langflow-ide/
  open-webui/

packaged-tgz/
  langflow-ide-1.10.0-pcai.4.tgz
  open-webui-8.12.2-pcai.2.tgz

langflow_wrapper_langflow_ide.py
scripts/package_charts.sh
```

## Cambios hechos

### Langflow

Se dejó el nombre original:

```text
Chart name: langflow-ide
fullnameOverride: langflow-service
backend service: langflow-service-backend
frontend service: langflow-service
postgres service: langflow-ide-postgresql-service
```

Se subió la versión del chart a:

```text
1.10.0-pcai.4
```

Se mantuvo la corrección del 403:

```text
LANGFLOW_API_KEY_SOURCE=env
LANGFLOW_API_KEY=langflow-pcai-internal-key
```

También se reemplazó el subchart roto de PostgreSQL por uno mínimo local para evitar el error de Helm lint:

```text
error calling include: no template "postgresql.v1.readReplicas.createExtendedConfigmap"
```

### Open WebUI

Se dejó el nombre original:

```text
Chart name: open-webui
```

Se subió la versión del chart a:

```text
8.12.2-pcai.2
```

Se mantiene:

```text
openaiBaseApiUrl: ""
```

para evitar conflicto con Pipelines.

## Cómo generar los `.tgz` manualmente

Desde la raíz del ZIP descomprimido:

```bash
chmod +x scripts/package_charts.sh
./scripts/package_charts.sh
```

Eso genera los `.tgz` en:

```text
generated-tgz/
```

## Cómo importar en HPE PCAI

Primero probá con los ya empacados:

```text
packaged-tgz/langflow-ide-1.10.0-pcai.4.tgz
packaged-tgz/open-webui-8.12.2-pcai.2.tgz
```

Si HPE vuelve a decir algo como:

```text
app release name already in use, UID: langflow-ide
```

entonces el problema no se resuelve solo con versión. Eso significa que HPE PCAI usa `Spec.Name`/UID como identificador único, no solo la versión. En ese caso hay dos opciones reales:

1. Borrar/desregistrar el framework viejo `langflow-ide` antes de importar este.
2. Usar la versión renombrada que te di antes, por ejemplo `langflow-ide-owui-lintfix`.

## Configuración del pipeline en Open WebUI

Subí este archivo:

```text
langflow_wrapper_langflow_ide.py
```

Valores recomendados:

```text
LANGFLOW_NAMESPACE = namespace-donde-instalaste-langflow
LANGFLOW_FLOW_ID = id-real-del-flow
LANGFLOW_API_TOKEN = langflow-pcai-internal-key
LANGFLOW_SERVICE_NAME = langflow-service-backend
LANGFLOW_SERVICE_PORT = 7860
VERIFY_SSL = false
LANGFLOW_BASE_URL =
```

Dejá `LANGFLOW_BASE_URL` vacío si usás `LANGFLOW_NAMESPACE`.

La URL interna final será:

```text
http://langflow-service-backend.<LANGFLOW_NAMESPACE>.svc.cluster.local:7860
```
