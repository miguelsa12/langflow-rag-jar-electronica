# HPE PCAI Langflow/Open WebUI - versión final lintfix

## Qué pasó

El error:

```text
FAILED JOB
Error: 1 chart(s) linted, 1 chart(s) failed
no template "postgresql.v1.readReplicas.createExtendedConfigmap"
```

significa que HPE PCAI ejecutó `helm lint` y el chart falló antes de instalarse.

El problema estaba en Langflow, dentro de `charts/postgresql`: el subchart de PostgreSQL venía incompleto/incompatible. Traía templates que llamaban helpers de Bitnami `postgresql.v1.*`, pero esos helpers no estaban disponibles en el paquete.

## Qué hice en esta versión

1. Renombré el framework otra vez para evitar cualquier residuo del intento fallido anterior:

```text
Chart name: langflow-ide-owui-lintfix
Release/resource base: langflow-owui-lintfix
Backend service: langflow-owui-lintfix-backend
PostgreSQL service: langflow-owui-lintfix-postgresql-service
Endpoint sugerido: langflow-owui-lintfix.${DOMAIN_NAME}
```

2. Reemplacé el subchart roto de PostgreSQL por uno mínimo y estable que crea solo lo necesario para Langflow:

```text
Secret: langflow-owui-lintfix-postgresql-service
Service: langflow-owui-lintfix-postgresql-service:5432
StatefulSet: langflow-owui-lintfix-postgresql-service
Database: langflow-db
User: langflow
Password: langflow-postgres
```

3. Mantengo la corrección del 403 original:

```text
LANGFLOW_API_KEY_SOURCE=env
LANGFLOW_API_KEY=langflow-pcai-internal-key
```

Y el wrapper usa:

```text
x-api-key: langflow-pcai-internal-key
```

no `Authorization: Bearer`.

## Qué importar en HPE PCAI

Importe estos archivos:

```text
langflow-ide-owui-lintfix-1.10.0-pcai.3.tgz
open-webui-langflow-8.12.2-pcai.1.tgz
```

Si Open WebUI ya lo importó bien antes, no hace falta reimportarlo. El que cambió para este error fue Langflow.

## Namespaces sugeridos

```text
Langflow namespace: langflow-owui-lintfix
Open WebUI namespace: openwebui-langflow
```

Pueden estar en namespaces diferentes.

## Qué subir en Open WebUI Pipelines

Suba:

```text
langflow_wrapper_lintfix.py
```

## Valores del pipeline

Configure:

```text
LANGFLOW_NAMESPACE = namespace-donde-instalaste-langflow
LANGFLOW_FLOW_ID = id-real-del-flow
LANGFLOW_API_TOKEN = langflow-pcai-internal-key
LANGFLOW_SERVICE_NAME = langflow-owui-lintfix-backend
LANGFLOW_SERVICE_PORT = 7860
VERIFY_SSL = false
LANGFLOW_BASE_URL =
```

Ejemplo:

```text
LANGFLOW_NAMESPACE = langflow-owui-lintfix
LANGFLOW_FLOW_ID = 12345678-abcd-1234-abcd-123456789abc
LANGFLOW_API_TOKEN = langflow-pcai-internal-key
LANGFLOW_SERVICE_NAME = langflow-owui-lintfix-backend
LANGFLOW_SERVICE_PORT = 7860
VERIFY_SSL = false
LANGFLOW_BASE_URL =
```

## Para dummies

El problema nuevo no era el `.py`.

Era como si el instalador abriera el paquete de Langflow, revisara PostgreSQL y encontrara piezas faltantes. Por eso ni siquiera llegaba a instalar.

Esta versión quita ese PostgreSQL roto y mete uno más simple, con los nombres exactos que Langflow necesita.
