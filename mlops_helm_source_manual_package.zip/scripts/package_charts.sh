#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC_DIR="$ROOT_DIR/helm-source"
OUT_DIR="$ROOT_DIR/generated-tgz"
mkdir -p "$OUT_DIR"

echo "==> Lint Langflow"
helm lint "$SRC_DIR/langflow-ide-owui-lintfix-source"

echo "==> Package Langflow"
helm package "$SRC_DIR/langflow-ide-owui-lintfix-source" --destination "$OUT_DIR"

echo "==> Lint Open WebUI"
helm lint "$SRC_DIR/open-webui-langflow-source"

echo "==> Package Open WebUI"
helm package "$SRC_DIR/open-webui-langflow-source" --destination "$OUT_DIR"

echo "Listo. TGZ generados en: $OUT_DIR"
ls -lh "$OUT_DIR"
