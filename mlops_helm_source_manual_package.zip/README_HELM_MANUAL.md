# Paquete fuente para generar los `.tgz` manualmente

Este ZIP trae los charts descomprimidos para que puedas revisarlos, editarlos y generar los `.tgz` con `helm package`.

## Qué trae

```text
helm-source/
  langflow-ide-owui-lintfix-source/
  open-webui-langflow-source/
packaged-tgz/
  langflow-ide-owui-lintfix-1.10.0-pcai.3.tgz
  open-webui-langflow-8.12.2-pcai.1.tgz
langflow_wrapper_lintfix.py
scripts/package_charts.sh
```

## Diagnóstico original

Había dos problemas separados:

1. El `403 Forbidden` venía porque el wrapper viejo enviaba autenticación como `Authorization: Bearer`, pero Langflow para `/api/v1/run/<flow_id>` debe recibir la API key como `x-api-key`.
2. El último error de importación ya no era del 403. Era de Helm lint: el subchart de PostgreSQL de Langflow venía incompatible/incompleto y llamaba un helper de Bitnami que no existía.

## Cambio mínimo aplicado

### Langflow

- Chart renombrado para no chocar con el framework viejo:
  - `langflow-ide-owui-lintfix`
- Backend service:
  - `langflow-owui-lintfix-backend`
- API key interna configurada:
  - `langflow-pcai-internal-key`
- PostgreSQL subchart simplificado para evitar el error de Helm lint.

### Open WebUI

- Chart renombrado:
  - `open-webui-langflow`
- Se mantiene Pipelines habilitado.

### Wrapper

- Archivo: `langflow_wrapper_lintfix.py`
- Usa `x-api-key` en vez de `Authorization: Bearer`.
- Arma la URL interna usando namespace:
  - `http://<service>.<namespace>.svc.cluster.local:<port>`

## Cómo generar los `.tgz` manualmente

Desde la carpeta descomprimida:

```bash
./scripts/package_charts.sh
```

Eso genera los `.tgz` en:

```text
generated-tgz/
```

## Comandos manuales equivalentes

```bash
mkdir -p generated-tgz

helm lint helm-source/langflow-ide-owui-lintfix-source
helm package helm-source/langflow-ide-owui-lintfix-source --destination generated-tgz

helm lint helm-source/open-webui-langflow-source
helm package helm-source/open-webui-langflow-source --destination generated-tgz
```

## Qué importar en HPE PCAI

Podés usar los `.tgz` ya listos dentro de `packaged-tgz/` o los que generés en `generated-tgz/`.

Para Langflow:

```text
langflow-ide-owui-lintfix-1.10.0-pcai.3.tgz
```

Para Open WebUI:

```text
open-webui-langflow-8.12.2-pcai.1.tgz
```

## Configuración del pipeline en Open WebUI

Subí `langflow_wrapper_lintfix.py` y configurá:

```text
LANGFLOW_NAMESPACE = <namespace-donde-instalaste-langflow>
LANGFLOW_FLOW_ID = <id-real-del-flow>
LANGFLOW_API_TOKEN = langflow-pcai-internal-key
LANGFLOW_SERVICE_NAME = langflow-owui-lintfix-backend
LANGFLOW_SERVICE_PORT = 7860
VERIFY_SSL = false
LANGFLOW_BASE_URL =
```

Dejá `LANGFLOW_BASE_URL` vacío para que el wrapper use el namespace.

## URL interna que debe construir

```text
http://langflow-owui-lintfix-backend.<LANGFLOW_NAMESPACE>.svc.cluster.local:7860
```

## Importante

No uses el JWT de HPE/PCAI para esta conexión interna.
No uses el wrapper viejo.
No uses el nombre viejo `langflow-ide`, porque HPE ya lo tiene ocupado.
